import Link from 'next/link';
import './globals.css';

export const metadata = {
  title: 'Healthy Kids App',
  description: 'Meal plans, workouts, and trackers for kids',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <header className="bg-blue-600 text-white p-4">
          <nav className="flex gap-4">
            <Link href="/dashboard">Dashboard</Link>
            <Link href="/meal-plans">Meal Plans</Link>
            <Link href="/workouts">Workouts</Link>
          </nav>
        </header>
        <main className="p-4">{children}</main>
      </body>
    </html>
  );
}
