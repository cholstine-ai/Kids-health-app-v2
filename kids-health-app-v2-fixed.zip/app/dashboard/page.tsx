'use client';
import { sampleMealPlans } from '@/lib/data/mealPlans';
import { sampleHIIT } from '@/lib/data/hiit';
import { useState } from 'react';

export default function DashboardPage() {
  const [waterCups, setWaterCups] = useState(0);
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-700">Dashboard</h1>
      <section className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold">Today's Meals</h2>
        <ul className="list-disc pl-6">
          {sampleMealPlans.slice(0,3).map((meal,i) => <li key={i}>{meal}</li>)}
        </ul>
      </section>
      <section className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold">Today's Workout</h2>
        <p>{sampleHIIT[0]}</p>
      </section>
      <section className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold">Water Tracker</h2>
        <p>Cups: {waterCups}</p>
        <div className="flex gap-2 flex-wrap">
          {[...Array(8)].map((_,i) => (
            <button key={i} onClick={()=>setWaterCups(i+1)}
              className={\`px-3 py-1 border rounded \${i<waterCups?'bg-blue-500 text-white':''}\`}>
              {i+1}
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
