'use client';
import { sampleMealPlans } from '@/lib/data/mealPlans';
import { sampleHIIT } from '@/lib/data/hiit';
import { useState } from 'react';
import { Line } from 'react-chartjs-2';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

export default function DashboardPage() {
  const [waterCups, setWaterCups] = useState(0);

  const progressLabels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
  const weightData = [130, 128, 126, 125];

  const chartData = {
    labels: progressLabels,
    datasets: [
      {
        label: 'Weight (lbs)',
        data: weightData,
        borderColor: 'rgb(37, 99, 235)',
        backgroundColor: 'rgba(37, 99, 235, 0.5)',
      },
    ],
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Weekly Progress Report', 14, 20);
    doc.setFontSize(12);
    doc.text('Meals:', 14, 30);
    sampleMealPlans.slice(0, 3).forEach((meal, i) => {
      doc.text(`- ${meal}`, 20, 40 + i * 10);
    });
    doc.text('Workout:', 14, 80);
    doc.text(sampleHIIT[0], 20, 90);
    doc.save('Progress_Report.pdf');
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-blue-700">Dashboard</h1>
      <section className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold">Today's Meals</h2>
        <ul className="list-disc pl-6">
          {sampleMealPlans.slice(0, 3).map((meal, i) => <li key={i}>{meal}</li>)}
        </ul>
      </section>
      <section className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold">Today's Workout</h2>
        <p>{sampleHIIT[0]}</p>
      </section>
      <section className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold">Water Tracker</h2>
        <p>Cups: {waterCups}</p>
        <div className="flex gap-2 flex-wrap">
          {[...Array(8)].map((_, i) => (
            <button key={i} onClick={() => setWaterCups(i + 1)}
              className={`px-3 py-1 border rounded ${i < waterCups ? 'bg-blue-500 text-white' : ''}`}>
              {i + 1}
            </button>
          ))}
        </div>
      </section>
      <section className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold mb-2">Progress Overview</h2>
        <div className="h-64">
          <Line data={chartData} />
        </div>
      </section>
      <button
        onClick={generatePDF}
        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
      >
        Download Progress PDF
      </button>
    </div>
  );
}
