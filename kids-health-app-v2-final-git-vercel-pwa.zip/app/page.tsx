export default function HomePage() {
  return (
    <div className="text-center space-y-4">
      <h1 className="text-4xl font-bold text-blue-700">Welcome to the Healthy Kids App</h1>
      <p className="text-lg">Track meals, workouts, and progress easily.</p>
      <a href="/dashboard" className="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Go to Dashboard
      </a>
    </div>
  );
}
