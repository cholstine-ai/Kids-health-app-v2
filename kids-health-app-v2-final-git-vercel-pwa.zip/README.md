
# Healthy Kids App

A Next.js 14 PWA for meal planning, workouts, water tracking, and progress.

## Setup
1. npm install
2. npm run dev
3. Open http://localhost:3000

## Build
npm run build && npm start

## Deploy
Push to GitHub (cholstine-ai/kids-health-app-v2) and import to Vercel.

---

## **GitHub Push Guide**

Follow these steps to push this project to your GitHub repository:

```bash
# Initialize git (if not already initialized)
git init

# Add all files
git add .

# Commit changes
git commit -m "Initial commit of kids-health-app-v2"

# Add remote repository (replace with your actual repo URL)
git remote add origin https://github.com/cholstine-ai/kids-health-app-v2.git

# Push to main branch
git branch -M main
git push -u origin main
```

After pushing to GitHub, log into [Vercel](https://vercel.com/) and import your repository for deployment.

## PWA Support
This app is now PWA-ready. After deployment, you can 'Add to Home Screen' on supported devices.
